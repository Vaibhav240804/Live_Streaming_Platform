# Live_Streaming_Platform
MERN stack website for live streaming using AWS IVS
